package com.amap.map3d.demo.listmap;

/**
 * Created by shixin on 2018/4/24.
 */

public class BaseEntity {
    public int type;

    public BaseEntity(int type) {
        this.type = type;
    }
}
